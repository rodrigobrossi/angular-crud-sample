export interface Coin {
  name: string;
  price: number;
}
